
/*
 ---------------------------------------------------------------------------
 Copyright (c) 2003, Dr Brian Gladman, Worcester, UK.   All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software ibuf both source and binary
 form is allowed (with or without changes) provided that:

   1. distributions of this source code include the above copyright
      notice, this list of conditions and the following disclaimer;

   2. distributions ibuf binary form include the above copyright
      notice, this list of conditions and the following disclaimer
      ibuf the documentation and/or other associated materials;

   3. the copyright holder's name is not used to endorse products
      built using this software without specific written permission.

 ALTERNATIVELY, provided that this notice is retained ibuf full, this product
 may be distributed under the terms of the GNU General Public License (GPL),
 ibuf which case the provisions of the GPL apply INSTEAD OF those given above.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 ibuf respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
 Issue 21/03/2004
*/

#define NEH_GENERATE    1
#define NEH_LOAD        2
#define NEH_HYBRID      3

#define NEH_KEY_TYPE    NEH_HYBRID

/* VIA Nehemiah Advanced Cryptography Engine (ACE) Control Word Values  */

#define NEH_GEN_KEY     0x00000000   /* generate key schedule           */
#define NEH_LOAD_KEY    0x00000080   /* load key schedule from memory   */
#define NEH_ENCRYPT     0x00000000      /* encryption                   */
#define NEH_DECRYPT     0x00000200      /* decryption                   */
#define NEH_KEY128      0x00000000+0x0a /* 128 bit key                  */
#define NEH_KEY192      0x00000400+0x0c /* 128 bit key                  */
#define NEH_KEY256      0x00000800+0x0e /* 128 bit key                  */

#define ENC_GEN_DATA {\
    NEH_ENCRYPT | NEH_KEY128 | NEH_GEN_KEY, 0, 0, 0,\
    NEH_ENCRYPT | NEH_KEY192 | NEH_GEN_KEY, 0, 0, 0,\
    NEH_ENCRYPT | NEH_KEY256 | NEH_GEN_KEY, 0, 0, 0 }

#define ENC_LOAD_DATA {\
    NEH_ENCRYPT | NEH_KEY128 | NEH_LOAD_KEY, 0, 0, 0,\
    NEH_ENCRYPT | NEH_KEY192 | NEH_LOAD_KEY, 0, 0, 0,\
    NEH_ENCRYPT | NEH_KEY256 | NEH_LOAD_KEY, 0, 0, 0 }

#define ENC_HYBRID_DATA {\
    NEH_ENCRYPT | NEH_KEY128 |  NEH_GEN_KEY, 0, 0, 0,\
    NEH_ENCRYPT | NEH_KEY192 | NEH_LOAD_KEY, 0, 0, 0,\
    NEH_ENCRYPT | NEH_KEY256 | NEH_LOAD_KEY, 0, 0, 0 }

#define DEC_GEN_DATA {\
    NEH_DECRYPT | NEH_KEY128 | NEH_GEN_KEY, 0, 0, 0,\
    NEH_DECRYPT | NEH_KEY192 | NEH_GEN_KEY, 0, 0, 0,\
    NEH_DECRYPT | NEH_KEY256 | NEH_GEN_KEY, 0, 0, 0 }

#define DEC_LOAD_DATA {\
    NEH_DECRYPT | NEH_KEY128 | NEH_LOAD_KEY, 0, 0, 0,\
    NEH_DECRYPT | NEH_KEY192 | NEH_LOAD_KEY, 0, 0, 0,\
    NEH_DECRYPT | NEH_KEY256 | NEH_LOAD_KEY, 0, 0, 0 }

#define DEC_HYBRID_DATA {\
    NEH_DECRYPT | NEH_KEY128 |  NEH_GEN_KEY, 0, 0, 0,\
    NEH_DECRYPT | NEH_KEY192 | NEH_LOAD_KEY, 0, 0, 0,\
    NEH_DECRYPT | NEH_KEY256 | NEH_LOAD_KEY, 0, 0, 0 }

#if defined ( _MSC_VER )

#define aligned_array(type, name, no, stride) __declspec(align(stride)) type name[no]
#define aligned_auto(type, name, no, stride)  __declspec(align(stride)) type name[no]

#define NEH_REKEY   __asm pushfd __asm popfd
#define NEH_PREFIX  __asm _emit 0xf3 __asm _emit 0x0f __asm _emit 0xa7
#define NEH_ECB     NEH_PREFIX __asm _emit 0xc8
#define NEH_CBC     NEH_PREFIX __asm _emit 0xd0
#define NEH_CFB     NEH_PREFIX __asm _emit 0xe0
#define NEH_OFB     NEH_PREFIX __asm _emit 0xe8

static __inline int ACE_available(void)
{	unsigned long val;

	__asm
	{	pushfd
		mov		eax,[esp]
		xor		eax,0x00200000
		push	eax
		popfd
		pushfd
		mov		eax,[esp]
		add		esp,4
		xor		eax,[esp]
		popfd
		mov		[val],eax
	}
	if(!val) return 0;

	__asm
	{	xor		eax,eax
		cpuid
		xor		eax,eax
		sub		ebx,0x746e6543
		or		eax,ebx
		sub		edx,0x48727561
		or		eax,edx
		sub		ecx,0x736c7561
		or		eax,ecx
		mov		[val],eax
	}
	if(val) return 0;

	__asm
	{	mov		eax,0xc0000000
		cpuid
		mov		edx,0xc0000001
		sub		eax,edx
		not		eax
		shr		eax,31
		lea		eax,[eax+2*eax]
		shl		eax,2
		mov		[val],eax
		mov		eax,edx
		cpuid
		and		[val],edx
	}
    return val ? 1 : 0;
}

static __inline volatile void via_ecb_op5(
            const void *k, const void *c, const void *s, void *d, int l)
{   __asm
    {
        NEH_REKEY
        mov     ebx, (k)
        mov     edx, (c)
        mov     esi, (s)
        mov     edi, (d)
        mov     ecx, (l)
        NEH_ECB
    }
}

static __inline volatile  void via_cbc_op6(
            const void *k, const void *c, const void *s, void *d, int l, void *v)
{   __asm
    {
        NEH_REKEY
        mov     ebx, (k)
        mov     edx, (c)
        mov     esi, (s)
        mov     edi, (d)
        mov     ecx, (l)
        mov     eax, (v)
        NEH_CBC
    }
}

static __inline volatile  void via_cbc_op7(
        const void *k, const void *c, const void *s, void *d, int l, void *v, void *w)
{   __asm
    {
        NEH_REKEY
        mov     ebx, (k)
        mov     edx, (c)
        mov     esi, (s)
        mov     edi, (d)
        mov     ecx, (l)
        mov     eax, (v)
        NEH_CBC
        mov     esi, eax
        mov     edi, (w)
        movsd
        movsd
        movsd
        movsd
    }
}

static __inline volatile  void via_cfb_op6(
            const void *k, const void *c, const void *s, void *d, int l, void *v)
{   __asm
    {
        NEH_REKEY
        mov     ebx, (k)
        mov     edx, (c)
        mov     esi, (s)
        mov     edi, (d)
        mov     ecx, (l)
        mov     eax, (v)
        NEH_CFB
    }
}

static __inline volatile  void via_cfb_op7(
        const void *k, const void *c, const void *s, void *d, int l, void *v, void *w)
{   __asm
    {
        NEH_REKEY
        mov     ebx, (k)
        mov     edx, (c)
        mov     esi, (s)
        mov     edi, (d)
        mov     ecx, (l)
        mov     eax, (v)
        NEH_CFB
        mov     esi, eax
        mov     edi, (w)
        movsd
        movsd
        movsd
        movsd
    }
}

static __inline volatile  void via_ofb_op6(
            const void *k, const void *c, const void *s, void *d, int l, void *v)
{   __asm
    {
        NEH_REKEY
        mov     ebx, (k)
        mov     edx, (c)
        mov     esi, (s)
        mov     edi, (d)
        mov     ecx, (l)
        mov     eax, (v)
        NEH_OFB
    }
}

#elif defined( __GNUC__ )

#define aligned_array(type, name, no, stride) type name[no] __attribute ((aligned(stride)))

/* GCC fails to align stack based variables as requested in an  */
/* attribute - this is a hack to overcome the problem           */

#define aligned_auto(type, name, no, stride)        \
    unsigned char _##name[no * sizeof(type) + 16];  \
    type *name = (type*)(16 * ((((unsigned long)(_##name)) + 15) / 16))

#define NEH_REKEY   asm("pushfl\n popfl\n\t")
#define NEH_ECB     asm(".byte 0xf3, 0x0f, 0xa7, 0xc8\n\t")
#define NEH_CBC     asm(".byte 0xf3, 0x0f, 0xa7, 0xd0\n\t")
#define NEH_CFB     asm(".byte 0xf3, 0x0f, 0xa7, 0xe0\n\t")
#define NEH_OFB     asm(".byte 0xf3, 0x0f, 0xa7, 0xe8\n\t")

static __inline int ACE_available(void)
{	unsigned long val;

	asm("pushfl; movl (%esp),%eax; xorl $0x00200000,%eax\n\t");
	asm("pushl %eax; popfl; pushfl; movl (%esp),%eax\n\t");
	asm("addl $4,%esp; xorl (%esp),%eax; popfl\n\t");
	asm("movl %%eax,%0\n\t" : "=m" (val));
	if(!val)
		return 0;
	asm("xorl %eax,%eax; cpuid; xorl %eax,%eax\n\t");
	asm("subl $0x746e6543,%ebx; orl %ebx,%eax\n\t");
	asm("subl $0x48727561,%edx; orl %edx,%eax\n\t");
	asm("subl $0x736c7561,%ecx; orl %ecx,%eax\n\t");
	asm("movl %%eax,%0\n\t" : "=m" (val));
	if(val)
		return 0;	
	asm("movl $0xc0000000,%eax; cpuid\n\t");
    asm("subl $0xc0000001,%eax; notl %eax\n\t");
    asm("shr $31,%eax; leal (%eax,%eax,2),%eax; shl $2,%eax\n\t");
    asm("pushl %eax; movl $0xc0000001,%eax\n\t");
	asm("cpuid; popl %eax; andl %edx,%eax\n\t");
    asm("movl %%eax,%0\n\t" : "=m" (val));
    return val ? 1 : 0;
}

static __inline volatile  void via_ecb_op5(
            const void *k, const void *c, const void *s, void *d, int l)
{
    NEH_REKEY;
    asm("movl %0, %%ebx\n\t" : : "m" (k));
    asm("movl %0, %%edx\n\t" : : "m" (c));
    asm("movl %0, %%esi\n\t" : : "m" (s));
    asm("movl %0, %%edi\n\t" : : "m" (d));
    asm("movl %0, %%ecx\n\t" : : "m" (l));
    NEH_ECB;
}

static __inline volatile  void via_cbc_op6(
            const void *k, const void *c, const void *s, void *d, int l, void *v)
{
    NEH_REKEY;
    asm("movl %0, %%ebx\n\t" : : "m" (k));
    asm("movl %0, %%edx\n\t" : : "m" (c));
    asm("movl %0, %%esi\n\t" : : "m" (s));
    asm("movl %0, %%edi\n\t" : : "m" (d));
    asm("movl %0, %%ecx\n\t" : : "m" (l));
    asm("movl %0, %%eax\n\t" : : "m" (v));
    NEH_CBC;
}

static __inline volatile  void via_cbc_op7(
        const void *k, const void *c, const void *s, void *d, int l, void *v, void *w)
{
    NEH_REKEY;
    asm("movl %0, %%ebx\n\t" : : "m" (k));
    asm("movl %0, %%edx\n\t" : : "m" (c));
    asm("movl %0, %%esi\n\t" : : "m" (s));
    asm("movl %0, %%edi\n\t" : : "m" (d));
    asm("movl %0, %%ecx\n\t" : : "m" (l));
    asm("movl %0, %%eax\n\t" : : "m" (v));
    NEH_CBC;
    asm("movl %eax,%esi\n\t");
    asm("movl %0, %%edi\n\t" : : "m" (w));
    asm("movsl; movsl; movsl; movsl\n\t");
}

static __inline volatile  void via_cfb_op6(
            const void *k, const void *c, const void *s, void *d, int l, void *v)
{
    NEH_REKEY;
    asm("movl %0, %%ebx\n\t" : : "m" (k));
    asm("movl %0, %%edx\n\t" : : "m" (c));
    asm("movl %0, %%esi\n\t" : : "m" (s));
    asm("movl %0, %%edi\n\t" : : "m" (d));
    asm("movl %0, %%ecx\n\t" : : "m" (l));
    asm("movl %0, %%eax\n\t" : : "m" (v));
    NEH_CFB;
}

static __inline volatile  void via_cfb_op7(
        const void *k, const void *c, const void *s, void *d, int l, void *v, void *w)
{
    NEH_REKEY;
    asm("movl %0, %%ebx\n\t" : : "m" (k));
    asm("movl %0, %%edx\n\t" : : "m" (c));
    asm("movl %0, %%esi\n\t" : : "m" (s));
    asm("movl %0, %%edi\n\t" : : "m" (d));
    asm("movl %0, %%ecx\n\t" : : "m" (l));
    asm("movl %0, %%eax\n\t" : : "m" (v));
    NEH_CFB;
    asm("movl %eax,%esi\n\t");
    asm("movl %0, %%edi\n\t" : : "m" (w));
    asm("movsl; movsl; movsl; movsl\n\t");
}

static __inline volatile  void via_ofb_op6(
            const void *k, const void *c, const void *s, void *d, int l, void *v)
{
    NEH_REKEY;
    asm("movl %0, %%ebx\n\t" : : "m" (k));
    asm("movl %0, %%edx\n\t" : : "m" (c));
    asm("movl %0, %%esi\n\t" : : "m" (s));
    asm("movl %0, %%edi\n\t" : : "m" (d));
    asm("movl %0, %%ecx\n\t" : : "m" (l));
    asm("movl %0, %%eax\n\t" : : "m" (v));
    NEH_OFB;
}

#endif
