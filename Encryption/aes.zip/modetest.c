/*
 ---------------------------------------------------------------------------
 Copyright (c) 2003, Dr Brian Gladman, Worcester, UK.   All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software ibuf both source and binary
 form is allowed (with or without changes) provided that:

   1. distributions of this source code include the above copyright
      notice, this list of conditions and the following disclaimer;

   2. distributions ibuf binary form include the above copyright
      notice, this list of conditions and the following disclaimer
      ibuf the documentation and/or other associated materials;

   3. the copyright holder's name is not used to endorse products
      built using this software without specific written permission.

 ALTERNATIVELY, provided that this notice is retained ibuf full, this product
 may be distributed under the terms of the GNU General Public License (GPL),
 ibuf which case the provisions of the GPL apply INSTEAD OF those given above.

 DISCLAIMER

 This software is provided 'as is' with no explicit or implied warranties
 ibuf respect of its properties, including, but not limited to, correctness
 and/or fitness for purpose.
 ---------------------------------------------------------------------------
 Issue 21/03/2004
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "aesopt.h"
#include "aes_modes.h"
#include "via_ace.h"

#define TEST_ECB
#define TEST_CBC
#define TEST_CFB
#define TEST_OFB
#define TEST_CTR

//#define WHOLE_BLOCKS
//#define VALIDATE_IN_TIMING

#if defined( _MSC_VER )

#define t_pro(hi,lo)                \
    __asm   {   __asm   push ebx    \
                __asm   push ecx    \
                __asm   cpuid       \
                __asm   rdtsc       \
                __asm   mov lo,eax  \
                __asm   mov hi,edx  \
                __asm   pop ecx     \
                __asm   pop ebx     \
            }

#define t_epi(hi,lo,cy)             \
    __asm   {   __asm   rdtsc       \
                __asm   sub eax,lo  \
                __asm   sbb edx,hi  \
                __asm   mov lo,eax  \
                __asm   mov hi,edx  \
            }                       \
    cy = ((unsigned long long)hi << 32) | lo

#define t_epif(hi,lo,cy)            \
    __asm   {   __asm   rdtsc       \
                __asm   sub eax,lo  \
                __asm   sbb edx,hi  \
                __asm   mov lo,eax  \
                __asm   mov hi,edx  \
            }                       \
    cy = (double)(((unsigned long long)hi << 32) | lo)

#else

#define t_pro(hi,lo) asm("cpuid; rdtsc\n\t");\
    asm("push %ebx; push %ecx\n\t");         \
    asm("movl %%eax,%0\n\t" : "=m" (lo));    \
    asm("movl %%edx,%0\n\t" : "=m" (hi));    \
    asm("pop %ecx; pop %ebx\n\t");

#define t_epi(hi,lo,cy)  asm("rdtsc\n\t");   \
    asm("subl %0,%%eax\n\t" : : "m" (lo));   \
    asm("sbbl %0,%%edx\n\t" : : "m" (hi));   \
    asm("movl %%eax,%0\n\t" : "=m" (lo));    \
    asm("movl %%edx,%0\n\t" : "=m" (hi));    \
    cy = ((unsigned long long)hi << 32) | lo

#define t_epif(hi,lo,cy) asm("rdtsc\n\t");   \
    asm("subl %0,%%eax\n\t" : : "m" (lo));   \
    asm("sbbl %0,%%edx\n\t" : : "m" (hi));   \
    asm("movl %%eax,%0\n\t" : "=m" (lo));    \
    asm("movl %%edx,%0\n\t" : "=m" (hi));    \
    cy = (double)(((unsigned long long)hi << 32) | lo)

#endif

#define SAMPLE1  1000
#define SAMPLE2 10000

unsigned int rand32(void)
{   static unsigned int   r4,r_cnt = (unsigned int)-1, w = 521288629, z = 362436069;

    z = 36969 * (z & 65535) + (z >> 16);
    w = 18000 * (w & 65535) + (w >> 16);

    r_cnt = 0; r4 = (z << 16) + w; return r4;
}

unsigned char rand8(void)
{   static unsigned int   r4,r_cnt = 4;

    if(r_cnt == 4)
    {
        r4 = rand32(); r_cnt = 0;
    }

    return (char)(r4 >> (8 * r_cnt++));
}

// fill a block with random charactrers

void block_rndfill(unsigned char l[], unsigned int len)
{   unsigned int  i;

    for(i = 0; i < len; ++i)

        l[i] = rand8();
}

void ECBenc(unsigned char *buf, int len, aes_encrypt_ctx cx[1])
{   int cnt = len / AES_BLOCK_SIZE;

    while(cnt--)
        aes_encrypt(buf, buf, cx), buf += AES_BLOCK_SIZE;
}

void ECBdec(unsigned char *buf, int len, aes_decrypt_ctx cx[1])
{   int cnt = len / AES_BLOCK_SIZE;

    while(cnt--)
        aes_decrypt(buf, buf, cx), buf += AES_BLOCK_SIZE;
}

void CBCenc(unsigned char *buf, int len, unsigned char *iv, aes_encrypt_ctx cx[1])
{   int cnt = len / AES_BLOCK_SIZE, i;

    while(cnt--)
    {
        for(i = 0; i < AES_BLOCK_SIZE; i++)
            buf[i] ^= iv[i];

        aes_encrypt(buf, buf, cx);
        memcpy(iv, buf, AES_BLOCK_SIZE);
        buf += AES_BLOCK_SIZE;
    }
}

void CBCdec(unsigned char *buf, int len, unsigned char *iv, aes_decrypt_ctx cx[1])
{   unsigned char temp[AES_BLOCK_SIZE];
    int cnt = len / AES_BLOCK_SIZE, i;

    while( cnt-- )
    {
        memcpy(temp, buf, AES_BLOCK_SIZE);
        aes_decrypt(buf, buf, cx);

        for(i = 0; i < AES_BLOCK_SIZE; i++)
            buf[i] ^= iv[i];

        memcpy(iv, temp, AES_BLOCK_SIZE);
        buf += AES_BLOCK_SIZE;
    }
}

void CFBenc(unsigned char *buf, int len, unsigned char *iv, aes_encrypt_ctx cx[1])
{   int i, nb, cnt = cx->inf.b[2];

    if(cnt)
    {
        nb = AES_BLOCK_SIZE - cnt;
        if(len < nb) nb = len;

        for(i = 0; i < nb; i++)
            buf[i] ^= iv[i + cnt];

        memcpy(iv + cnt, buf, nb);
        len -= nb, buf += nb, cnt += nb;
    }

    while(len)
    {
        cnt = (len > AES_BLOCK_SIZE) ? AES_BLOCK_SIZE : len;
        aes_encrypt(iv, iv, cx);
        for(i = 0; i < cnt; i++)
            buf[i] ^= iv[i];
        memcpy(iv, buf, cnt);
        len -= cnt, buf += cnt;
    }

    cx->inf.b[2] = (cnt % AES_BLOCK_SIZE);
}

void CFBdec(unsigned char *buf, int len, unsigned char *iv, aes_encrypt_ctx cx[1])
{   unsigned char temp[AES_BLOCK_SIZE];
    int i, nb, cnt = cx->inf.b[2];

    if(cnt)
    {
        nb = AES_BLOCK_SIZE - cnt;
        if(len < nb) nb = len;
        memcpy(temp, buf, nb);

        for(i = 0; i < nb; i++)
            buf[i] ^= iv[i + cnt];

        memcpy(iv + cnt, temp, nb);
        len -= nb, buf += nb, cnt += nb;
    }

    while(len)
    {
        cnt = (len > AES_BLOCK_SIZE) ? AES_BLOCK_SIZE : len;
        aes_encrypt(iv, iv, cx);
        memcpy(temp, buf, cnt);

        for(i = 0; i < cnt; i++)
            buf[i] ^= iv[i];

        memcpy(iv, temp, cnt);
        len -= cnt, buf += cnt;
    }
    cx->inf.b[2] = (cnt % AES_BLOCK_SIZE);
}

void OFBenc(unsigned char *buf, int len, unsigned char *iv, aes_encrypt_ctx cx[1])
{   int i, nb, cnt = cx->inf.b[2];

    if(cnt)
    {
        nb = AES_BLOCK_SIZE - cnt;
        if(len < nb) nb = len;

        for(i = 0; i < nb; i++)
            buf[i] ^= iv[i + cnt];

        len -= nb, buf += nb, cnt += nb;
    }

    while(len)
    {
        cnt = (len > AES_BLOCK_SIZE) ? AES_BLOCK_SIZE : len;
        aes_encrypt(iv, iv, cx);

        for(i = 0; i < cnt; i++)
            buf[i] ^= iv[i];

        len -= cnt, buf += cnt;
    }

    cx->inf.b[2] = (cnt % AES_BLOCK_SIZE);
}

void OFBdec(unsigned char *buf, int len, unsigned char *iv, aes_encrypt_ctx cx[1])
{   int i, nb, cnt = cx->inf.b[2];

    if( cnt )
    {
        nb = AES_BLOCK_SIZE - cnt;
        if(len < nb) nb = len;

        for(i = 0; i < nb; i++)
            buf[i] ^= iv[i + cnt];

        len -= nb, buf += nb, cnt += nb;
    }

    while(len)
    {
        cnt = (len > AES_BLOCK_SIZE) ? AES_BLOCK_SIZE : len;
        aes_encrypt(iv, iv, cx);

        for(i = 0; i < cnt; i++)
            buf[i] ^= iv[i];

        len -= cnt, buf += cnt;
    }

    cx->inf.b[2] = (cnt % AES_BLOCK_SIZE);
}

void CTRcry(unsigned char *buf, int len, unsigned char *cbuf, cbuf_inc *incf, aes_encrypt_ctx cx[1])
{   int i, cnt;
    aes_08t ecbuf[AES_BLOCK_SIZE];

    while(len)
    {
        cnt = (len > AES_BLOCK_SIZE) ? AES_BLOCK_SIZE : len;
        aes_encrypt(cbuf, ecbuf, cx);
        if(cnt == AES_BLOCK_SIZE)
            incf(cbuf);

        for(i = 0; i < cnt; i++)
            buf[i] ^= ecbuf[i];

        len -= cnt, buf += cnt;
    }
}


int time_base(double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;

    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
}

#ifdef TEST_ECB

int time_ecb_enc(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_ecb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, ecx);
#ifdef VALIDATE_IN_TIMING
    ECBenc(vb, blocks * AES_BLOCK_SIZE, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_ecb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            ECBenc(vb, blocks * AES_BLOCK_SIZE, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_ecb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            ECBenc(vb, blocks * AES_BLOCK_SIZE, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error:
    printf("\nECB Encryption data error in timing");
    exit(1);
#endif
}

int time_ecb_dec(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(aes_decrypt_ctx, dcx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    aes_decrypt_ctx dcx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_decrypt_key(key, k_len, dcx);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_ecb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, dcx);
#ifdef VALIDATE_IN_TIMING
    ECBdec(vb, blocks * AES_BLOCK_SIZE, dcx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error;
#endif
    tol = 10; lcnt = sam_cnt = 0;

    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_ecb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, dcx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            ECBdec(vb, blocks * AES_BLOCK_SIZE, dcx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_ecb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, dcx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            ECBdec(vb, blocks * AES_BLOCK_SIZE, dcx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error:
    printf("\nECB Encryption data error in timing");
    exit(1);
#endif
}

#endif

#ifdef TEST_CBC

int time_cbc_enc(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, iv, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   iv[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(iv, AES_BLOCK_SIZE);
    memcpy(viv, iv, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_cbc_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
#ifdef VALIDATE_IN_TIMING
    CBCenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, iv, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_cbc_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            CBCenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_cbc_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            CBCenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nCBC Encryption data error in timing");
    exit(1);
error2:
    printf("\nCBC Encryption iv error in timing");
    exit(1);
#endif
}

int time_cbc_dec(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, iv, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_decrypt_ctx, dcx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   iv[AES_BLOCK_SIZE];
    aes_decrypt_ctx dcx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_decrypt_key(key, k_len, dcx);
    block_rndfill(iv, AES_BLOCK_SIZE);
    memcpy(viv, iv, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_cbc_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, dcx);
#ifdef VALIDATE_IN_TIMING
    CBCdec(vb, blocks * AES_BLOCK_SIZE, viv, dcx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, iv, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_cbc_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, dcx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            CBCdec(vb, blocks * AES_BLOCK_SIZE, viv, dcx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_cbc_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, dcx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            CBCdec(vb, blocks * AES_BLOCK_SIZE, viv, dcx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nCBC Decryption data error in timing");
    exit(1);
error2:
    printf("\nCBC Decryption iv error in timing");
    exit(1);
#endif
}

#endif

#ifdef TEST_CFB

int time_cfb_enc(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, iv, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   iv[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(iv, AES_BLOCK_SIZE);
    memcpy(viv, iv, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_cfb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
#ifdef VALIDATE_IN_TIMING
    CFBenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, iv, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_cfb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            CFBenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_cfb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            CFBenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nCFB Encryption data error in timing");
    exit(1);
error2:
    printf("\nCFB Encryption iv error in timing");
    exit(1);
#endif
}

int time_cfb_dec(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, iv, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   iv[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(iv, AES_BLOCK_SIZE);
    memcpy(viv, iv, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_cfb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
#ifdef VALIDATE_IN_TIMING
    CFBdec(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, iv, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_cfb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            CFBdec(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_cfb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            CFBdec(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nCFB Decryption data error in timing");
    exit(1);
error2:
    printf("\nCFB Decryption iv error in timing");
    exit(1);
#endif
}

#endif

#ifdef TEST_OFB

int time_ofb_enc(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, iv, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   iv[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(iv, AES_BLOCK_SIZE);
    memcpy(viv, iv, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_ofb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
#ifdef VALIDATE_IN_TIMING
    OFBenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, iv, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_ofb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            OFBenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_ofb_encrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            OFBenc(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nOFB Encryption data error in timing");
    exit(1);
error2:
    printf("\nOFB Encryption iv error in timing");
    exit(1);
#endif
}

int time_ofb_dec(unsigned int k_len, int blocks, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, iv, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   iv[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(iv, AES_BLOCK_SIZE);
    memcpy(viv, iv, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_ofb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
#ifdef VALIDATE_IN_TIMING
    OFBdec(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, iv, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_ofb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            OFBdec(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_ofb_decrypt(pt, pt, blocks * AES_BLOCK_SIZE, iv, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            OFBdec(vb, blocks * AES_BLOCK_SIZE, viv, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, iv, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nOFB Decryption data error in timing");
    exit(1);
error2:
    printf("\nOFB Decryption iv error in timing");
    exit(1);
#endif
}

#endif

#ifdef TEST_CTR

int time_ctr_crypt(unsigned int k_len, int blocks, cbuf_inc ctr_inc, double *av, double *sig)
{   int                 i, tol, lcnt, sam_cnt;
    unsigned int        yl, yh;
    double              cy, av1, sig1;
    unsigned char       key[2 * AES_BLOCK_SIZE];
    unsigned char       vb[10000 * AES_BLOCK_SIZE];
    unsigned char       viv[AES_BLOCK_SIZE];

#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, pt, 10000 * AES_BLOCK_SIZE, 16);
    aligned_auto(unsigned char, cbuf, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx, 1, 16);
#else
    unsigned char   pt[10000 * AES_BLOCK_SIZE];
    unsigned char   cbuf[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx[1];
#endif

    block_rndfill(key, 2 * AES_BLOCK_SIZE);
    aes_encrypt_key(key, k_len, ecx);
    block_rndfill(cbuf, AES_BLOCK_SIZE);
    memcpy(viv, cbuf, AES_BLOCK_SIZE);
    block_rndfill(pt, blocks * AES_BLOCK_SIZE);
    memcpy(vb, pt, blocks * AES_BLOCK_SIZE);
    aes_ctr_crypt(pt, pt, blocks * AES_BLOCK_SIZE, cbuf, ctr_inc, ecx);
#ifdef VALIDATE_IN_TIMING
    CTRcry(vb, blocks * AES_BLOCK_SIZE, viv, ctr_inc, ecx);
    if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
        goto error1;
    if(memcmp(viv, cbuf, AES_BLOCK_SIZE))
        goto error2;
#endif
    tol = 10; lcnt = sam_cnt = 0;
    while(!sam_cnt)
    {
        av1 = sig1 = 0.0;

        for(i = 0; i < SAMPLE1; ++i)
        {
            t_pro(yh, yl);
            aes_ctr_crypt(pt, pt, blocks * AES_BLOCK_SIZE, cbuf, ctr_inc, ecx);
            t_epif(yh, yl, cy);

            av1 += cy;
            sig1 += cy * cy;
#ifdef VALIDATE_IN_TIMING
            CTRcry(vb, blocks * AES_BLOCK_SIZE, viv, ctr_inc, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, cbuf, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        av1 /= SAMPLE1;
        sig1 = sqrt((sig1 - av1 * av1 * SAMPLE1) / SAMPLE1);
        sig1 = (sig1 < 0.05 * av1 ? 0.05 * av1 : sig1);

        *av = *sig = 0.0;
        for(i = 0; i < SAMPLE2; ++i)
        {
            t_pro(yh, yl);
            aes_ctr_crypt(pt, pt, blocks * AES_BLOCK_SIZE, cbuf, ctr_inc, ecx);
            t_epif(yh, yl, cy);

            if(cy > av1 - sig1 && cy < av1 + sig1)
            {
                *av += cy;
                *sig += cy * cy;
                sam_cnt++;
            }
#ifdef VALIDATE_IN_TIMING
            CTRcry(vb, blocks * AES_BLOCK_SIZE, viv, ctr_inc, ecx);
            if(memcmp(pt, vb, blocks * AES_BLOCK_SIZE))
                goto error1;
            if(memcmp(viv, cbuf, AES_BLOCK_SIZE))
                goto error2;
#endif
        }

        if(10 * sam_cnt > 9 * SAMPLE2)
        {
            *av /= sam_cnt;
            *sig = sqrt((*sig - *av * *av * sam_cnt) / sam_cnt);
            if(*sig > (tol / 100.0) * *av)
                sam_cnt = 0;
        }
        else
        {
            if(lcnt++ == 10)
            {
                lcnt = 0; tol += 5;
                if(tol > 30)
                    return 0;
            }
            sam_cnt = 0;
        }
    }

    return 1;
#ifdef VALIDATE_IN_TIMING
error1:
    printf("\nOFB Decryption data error in timing");
    exit(1);
error2:
    printf("\nOFB Decryption cbuf error in timing");
    exit(1);
#endif
}

#endif

void ctr_inc(unsigned char x[AES_BLOCK_SIZE])
{
    if(!(++(x[0])))
        if(!(++(x[1])))
            if(!(++(x[2])))
                if(!(++(x[3])))
                    ;
}

#define BUFLEN  (1000 * AES_BLOCK_SIZE)

int main(void)
{   int     i, k, err, blocks, len, len2;
    double  a0, av, sig, td;
    unsigned char   buf1[BUFLEN];
    unsigned char   buf2[BUFLEN];
    unsigned char   iv1[AES_BLOCK_SIZE];
    unsigned char   iv2[AES_BLOCK_SIZE];
    unsigned char   key[32];
    aes_encrypt_ctx ecx1[1];
    aes_decrypt_ctx dcx1[1];
#if defined( VIA_ACE_SUPPORT )
    aligned_auto(unsigned char, buf3, BUFLEN, 16);
    aligned_auto(unsigned char, iv3, AES_BLOCK_SIZE, 16);
    aligned_auto(aes_encrypt_ctx, ecx2, 1, 16);
    aligned_auto(aes_decrypt_ctx, dcx2, 1, 16);
#else
    unsigned char   buf3[BUFLEN];
    unsigned char   iv3[AES_BLOCK_SIZE];
    aes_encrypt_ctx ecx2[1];
    aes_decrypt_ctx dcx2[1];
#endif

    for(k = 128; k <= 256; k += 64)
    {
        printf("\n\n%03i Bit Keys", k);
#ifdef TEST_ECB
        err = 0;
        for(i = 0; i < 100; ++i)
        {
            block_rndfill(key, 2 * AES_BLOCK_SIZE);
            aes_encrypt_key(key, k, ecx1);
            aes_encrypt_key(key, k, ecx2);
            aes_decrypt_key(key, k, dcx1);
            aes_decrypt_key(key, k, dcx2);

            block_rndfill(buf1, BUFLEN);
            memcpy(buf2, buf1, BUFLEN);
            memcpy(buf3, buf1, BUFLEN);

            td = rand32() / (65536.0 * 65536.0);
            len = (unsigned int)(0.5 * BUFLEN * (1.0 + td));
            len = AES_BLOCK_SIZE * (len / AES_BLOCK_SIZE);

            ECBenc(buf2, len, ecx1);
            aes_ecb_encrypt(buf3, buf3, len, ecx2);

            if(memcmp(buf2, buf3, len)) err |= 1;
            if((err & 1) && !(err & 256))
                printf("\nECB encryption FAILURE");

            ECBdec(buf2, len, dcx1);
            aes_ecb_decrypt(buf3, buf3, len, dcx2);

            if(memcmp(buf1, buf2, len)) err |= 2;
            if(memcmp(buf1, buf3, len)) err |= 4;
            if((err & 4) && !(err & 512))
                printf("\nECB decryption FAILURE");
            if(err & 1)
                err |= 256;
            if(err & 4)
                err |= 512;
        }
        if(!err)
            printf("\nECB encrypt and decrypt of data correct");
#endif

#ifdef TEST_CBC
        err = 0;
        for(i = 0; i < 100; ++i)
        {
            block_rndfill(key, 2 * AES_BLOCK_SIZE);
            aes_encrypt_key(key, k, ecx1);
            aes_encrypt_key(key, k, ecx2);
            aes_decrypt_key(key, k, dcx1);
            aes_decrypt_key(key, k, dcx2);

            block_rndfill(iv1, AES_BLOCK_SIZE);
            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            block_rndfill(buf1, BUFLEN);
            memcpy(buf2, buf1, BUFLEN);
            memcpy(buf3, buf1, BUFLEN);

            td = rand32() / (65536.0 * 65536.0);
            len = (unsigned int)(0.5 * BUFLEN * (1.0 + td));
            len = AES_BLOCK_SIZE * (len / AES_BLOCK_SIZE);

            CBCenc(buf2, len, iv2, ecx1);
            aes_cbc_encrypt(buf3, buf3, len, iv3, ecx2);

            if(memcmp(buf2, buf3, len)) err |= 1;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 2;
            if((err & 1) && !(err & 256))
                printf("\nCBC encryption FAILURE");

            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);
            CBCdec(buf2, len, iv2, dcx1);
            aes_cbc_decrypt(buf3, buf3, len, iv3, dcx2);

            if(memcmp(buf1, buf2, len)) err |= 4;
            if(memcmp(buf1, buf3, len)) err |= 8;
            if(memcmp(buf2, buf3, len)) err |= 16;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 32;
            if((err & 16) && !(err & 512))
                printf("\nCBC decryption FAILURE");
            if(err & 1)
                err |= 256;
            if(err & 16)
                err |= 512;
        }
        if(!(err & ~(2 | 4 | 16 | 32)))
            printf("\nCBC encrypt and decrypt of data correct");
        if(err & (2 | 32))
        {
            printf(" (mismatch of final IV on ");
            if(err & 2)
                printf("encrypt");
            if((err & (2 | 32)) == 34)
                printf(" and ");
            if(err & 32)
                printf("decrypt");
            printf(")");
        }
#endif

#ifdef TEST_CFB
        err = 0;
        for(i = 0; i < 100; ++i)
        {
            block_rndfill(key, 2 * AES_BLOCK_SIZE);
            aes_encrypt_key(key, k, ecx1);
            aes_encrypt_key(key, k, ecx2);
            aes_decrypt_key(key, k, dcx1);
            aes_decrypt_key(key, k, dcx2);

            block_rndfill(iv1, AES_BLOCK_SIZE);
            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            block_rndfill(buf1, BUFLEN);
            memcpy(buf2, buf1, BUFLEN);
            memcpy(buf3, buf1, BUFLEN);

            ecx1->inf.b[2] = 0;
            aes_mode_reset(ecx2);
            td = rand32() / (65536.0 * 65536.0);
            len = (unsigned int)(0.5 * BUFLEN * (1.0 + td));
            td = rand32() / (65536.0 * 65536.0);
            len2 = (unsigned int)(td * len);
#ifdef WHOLE_BLOCKS
            len = AES_BLOCK_SIZE * (len / AES_BLOCK_SIZE);
            len2 = AES_BLOCK_SIZE * (len2 / AES_BLOCK_SIZE);
#endif
            aes_cfb_encrypt(buf3, buf3, len2, iv3, ecx2);
            aes_cfb_encrypt(buf3 + len2, buf3 + len2, len - len2, iv3, ecx2);

            CFBenc(buf2, len, iv2, ecx1);
            if(memcmp(buf2, buf3, len)) err |= 1;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 2;
            if((err & 1) && !(err & 256))
                printf("\nCFB encryption FAILURE");

            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            ecx1->inf.b[2] = 0;
            aes_mode_reset(ecx2);
            CFBdec(buf2, len, iv2, ecx1);
            td = rand32() / (65536.0 * 65536.0);
            len2 = (unsigned int)(td * len);
#ifdef WHOLE_BLOCKS
            len2 = AES_BLOCK_SIZE * (len2 / AES_BLOCK_SIZE);
#endif
            aes_cfb_decrypt(buf3, buf3, len2, iv3, ecx2);
            aes_cfb_decrypt(buf3 + len2, buf3 + len2, len - len2, iv3, ecx2);

            if(memcmp(buf1, buf2, len)) err |= 4;
            if(memcmp(buf1, buf3, len)) err |= 8;
            if(memcmp(buf2, buf3, len)) err |= 16;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 32;
            if((err & 16) && !(err & 512))
                printf("\nCFB decryption FAILURE");
            if(err & 1)
                err |= 256;
            if(err & 16)
                err |= 512;
        }
        if(!(err & ~(2 | 4 | 16 | 32)))
            printf("\nCFB encrypt and decrypt of data correct");
        if(err & (2 | 32))
        {
            printf(" (mismatch of final IV on ");
            if(err & 2)
                printf("encrypt");
            if((err & (2 | 32)) == 34)
                printf(" and ");
            if(err & 32)
                printf("decrypt");
            printf(")");
        }
#endif

#ifdef TEST_OFB
        err = 0;
        for(i = 0; i < 100; ++i)
        {
            block_rndfill(key, 2 * AES_BLOCK_SIZE);
            aes_encrypt_key(key, k, ecx1);
            aes_encrypt_key(key, k, ecx2);
            aes_decrypt_key(key, k, dcx1);
            aes_decrypt_key(key, k, dcx2);

            block_rndfill(iv1, AES_BLOCK_SIZE);
            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            block_rndfill(buf1, BUFLEN);
            memcpy(buf2, buf1, BUFLEN);
            memcpy(buf3, buf1, BUFLEN);

            ecx1->inf.b[2] = 0;
            aes_mode_reset(ecx2);
            td = rand32() / (65536.0 * 65536.0);
            len = (unsigned int)(0.5 * BUFLEN * (1.0 + td));
            td = rand32() / (65536.0 * 65536.0);
            len2 = (unsigned int)(td * len);
#ifdef WHOLE_BLOCKS
            len = AES_BLOCK_SIZE * (len / AES_BLOCK_SIZE);
            len2 = AES_BLOCK_SIZE * (len2 / AES_BLOCK_SIZE);
#endif
            aes_ofb_encrypt(buf3, buf3, len2, iv3, ecx2);
            aes_ofb_encrypt(buf3 + len2, buf3 + len2, len - len2, iv3, ecx2);

            OFBenc(buf2, len, iv2, ecx1);
            if(memcmp(buf2, buf3, len)) err |= 1;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 2;
            if((err & 1) && !(err & 256))
                printf("\nOFB encryption FAILURE");

            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            ecx1->inf.b[2] = 0;
            aes_mode_reset(ecx2);
            OFBdec(buf2, len, iv2, ecx1);
            td = rand32() / (65536.0 * 65536.0);
            len2 = (unsigned int)(td * len);
#ifdef WHOLE_BLOCKS
            len2 = AES_BLOCK_SIZE * (len2 / AES_BLOCK_SIZE);
#endif
            aes_ofb_decrypt(buf3, buf3, len2, iv3, ecx2);
            aes_ofb_decrypt(buf3 + len2, buf3 + len2, len - len2, iv3, ecx2);

            if(memcmp(buf1, buf2, len)) err |= 4;
            if(memcmp(buf1, buf3, len)) err |= 8;
            if(memcmp(buf2, buf3, len)) err |= 16;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 32;
            if((err & 16) && !(err & 512))
                printf("\nOFB decryption FAILURE");
            if(err & 1)
                err |= 256;
            if(err & 16)
                err |= 512;
        }
        if(!(err & ~(2 | 4 | 16 | 32)))
            printf("\nOFB encrypt and decrypt of data correct");
        if(err & (2 | 32))
        {
            printf(" (mismatch of final IV on ");
            if(err & 2)
                printf("encrypt");
            if((err & (2 | 32)) == 34)
                printf(" and ");
            if(err & 32)
                printf("decrypt");
            printf(")");
        }
#endif

#ifdef TEST_CTR
        err = 0;
        for(i = 0; i < 100; ++i)
        {
            block_rndfill(key, 2 * AES_BLOCK_SIZE);
            aes_encrypt_key(key, k, ecx1);
            aes_encrypt_key(key, k, ecx2);
            aes_decrypt_key(key, k, dcx1);
            aes_decrypt_key(key, k, dcx2);

            block_rndfill(iv1, AES_BLOCK_SIZE);
            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            block_rndfill(buf1, BUFLEN);
            memcpy(buf2, buf1, BUFLEN);
            memcpy(buf3, buf1, BUFLEN);

            ecx1->inf.b[2] = 0;
            aes_mode_reset(ecx2);
            td = rand32() / (65536.0 * 65536.0);
            len = (unsigned int)(0.5 * BUFLEN * (1.0 + td));
            td = rand32() / (65536.0 * 65536.0);
            len2 = (unsigned int)(td * len);
#ifdef WHOLE_BLOCKS
            len = AES_BLOCK_SIZE * (len / AES_BLOCK_SIZE);
            len2 = AES_BLOCK_SIZE * (len2 / AES_BLOCK_SIZE);
#endif
            aes_ctr_crypt(buf3, buf3, len2, iv3, ctr_inc, ecx2);
            aes_ctr_crypt(buf3 + len2, buf3 + len2, len - len2, iv3, ctr_inc, ecx2);

            CTRcry(buf2, len, iv2, ctr_inc, ecx1);
            if(memcmp(buf2, buf3, len)) err |= 1;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 2;
            if((err & 1) && !(err & 256))
                printf("\nCTR encryption FAILURE");

            memcpy(iv2, iv1, AES_BLOCK_SIZE);
            memcpy(iv3, iv1, AES_BLOCK_SIZE);

            ecx1->inf.b[2] = 0;
            aes_mode_reset(ecx2);
            td = rand32() / (65536.0 * 65536.0);
            len2 = (unsigned int)(td * len);
            CTRcry(buf2, len, iv2, ctr_inc, ecx1);
#ifdef WHOLE_BLOCKS
            len2 = AES_BLOCK_SIZE * (len2 / AES_BLOCK_SIZE);
#endif
            aes_ctr_crypt(buf3, buf3, len2, iv3, ctr_inc, ecx2);
            aes_ctr_crypt(buf3 + len2, buf3 + len2, len - len2, iv3, ctr_inc, ecx2);

            if(memcmp(buf1, buf2, len)) err |= 4;
            if(memcmp(buf1, buf3, len)) err |= 8;
            if(memcmp(buf2, buf3, len)) err |= 16;
            if(memcmp(iv2, iv3, AES_BLOCK_SIZE)) err |= 32;
            if((err & 16) && !(err & 512))
                printf("\nCTR decryption FAILURE");
            if(err & 1)
                err |= 256;
            if(err & 16)
                err |= 512;
        }
        if(!(err & ~(2 | 4 | 16 | 32)))
            printf("\nCTR encrypt and decrypt of data correct");
        if(err & (2 | 32))
        {
            printf(" (mismatch of final IV on ");
            if(err & 2)
                printf("encrypt");
            if((err & (2 | 32)) == 34)
                printf(" and ");
            if(err & 32)
                printf("decrypt");
            printf(")");
        }
#endif
    }

    printf("\n\nAES Timing (Cycles/Byte) with the VIA ACE Engine");
    printf("\nMode   Blocks:      1       10      100     1000");

#ifdef TEST_ECB
    printf("\necb encrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_ecb_enc(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }

    printf("\necb decrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_ecb_dec(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }
#endif

#ifdef TEST_CBC
    printf("\ncbc encrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_cbc_enc(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }

    printf("\ncbc decrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_cbc_dec(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }
#endif

#ifdef TEST_CFB
    printf("\ncfb encrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_cfb_enc(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }

    printf("\ncfb decrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_cfb_dec(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }
#endif

#ifdef TEST_OFB
    printf("\nofb encrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_ofb_enc(16, blocks, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }

#endif

#ifdef TEST_CTR
    printf("\nctr encrypt ");
    for(blocks = 1; blocks < 10000; blocks *= 10)
    {
        time_base(&a0, &sig);
        time_ctr_crypt(16, blocks, ctr_inc, &av, &sig);
        sig *= 100.0 / av;
        av = (int)(100.0 * (av - a0) / (16.0 * blocks)) / 100.0;
        sig = (int)(10 * sig) / 10.0;
        printf("%9.2f", av);
    }

#endif

    printf("\n\n");
    return 0;
}
